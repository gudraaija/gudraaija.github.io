Kursa darba info-grafika.
